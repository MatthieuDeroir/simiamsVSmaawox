echo "${bcRed}"
