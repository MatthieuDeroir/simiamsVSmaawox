echo "${bcBlack}"
