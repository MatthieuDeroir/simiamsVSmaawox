//
// Created by Matthieu Deroir on 06/04/2022.
//

#ifndef SIMIAMSVSMAAWOX_DEFINES_H
#define SIMIAMSVSMAAWOX_DEFINES_H

#include "Player.h"

Player* playerInitialization();

#endif //SIMIAMSVSMAAWOX_DEFINES_H
